﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $rootnamespace$
{
    /// <summary>
    /// 
    /// </summary>
    class $safeitemname$
    {

        
        #region "Propriétés privées"
        
        #endregion


        #region "Proprités publiques"
        

        #endregion

        #region "Constructeurs"
       
        #endregion


        #region "Methodes privées"

        #endregion


        #region "Méthode publiques"

        #endregion

    }
}






